package com.example.arrowsolver

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var output: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
        }

        val title = TextView(this).apply {
            text = "Arrow Solver"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
        }
        content.addView(title)

        val subtitle = TextView(this).apply {
            text = "Prototype 0.1 • Puzzle engine test"
            textSize = 14f
            setPadding(0, 8, 0, 24)
        }
        content.addView(subtitle)

        val description = TextView(this).apply {
            text = "This build tests the elimination logic using a sample board. Live game recognition and automatic tapping are the next development stages."
            textSize = 16f
        }
        content.addView(description)

        val run = Button(this).apply {
            text = "Solve sample puzzle"
            setOnClickListener { runDemo() }
        }
        content.addView(run)

        output = TextView(this).apply {
            textSize = 16f
            setPadding(0, 24, 0, 0)
        }
        val scroll = ScrollView(this).apply { addView(output) }
        content.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(content)
        runDemo()
    }

    private fun runDemo() {
        // Arrow A points left and has a clear route to the edge.
        // Arrow B points left but is initially blocked by Arrow A.
        val board = Board(
            width = 5,
            height = 3,
            arrows = listOf(
                Arrow("A", listOf(Cell(1, 1), Cell(2, 1)), Cell(1, 1), Direction.LEFT),
                Arrow("B", listOf(Cell(3, 1), Cell(4, 1)), Cell(3, 1), Direction.LEFT)
            )
        )

        val result = ArrowSolver.solve(board)
        output.text = buildString {
            appendLine("SAMPLE BOARD: 5 × 3")
            appendLine()
            appendLine("Expected: A must leave before B.")
            appendLine()
            when (result) {
                is SolveResult.Solved -> {
                    appendLine("PUZZLE SOLVED")
                    result.order.forEachIndexed { index, id ->
                        appendLine("${index + 1}. Remove arrow $id")
                    }
                }
                is SolveResult.Stuck -> {
                    appendLine("NO COMPLETE SOLUTION FOUND")
                    appendLine("Remaining arrows: ${result.remainingIds.joinToString()}")
                    appendLine("Blocking details:")
                    result.blockers.forEach { (id, blockers) ->
                        appendLine("$id is blocked by ${blockers.joinToString()}")
                    }
                }
                is SolveResult.Invalid -> appendLine("Invalid board: ${result.reason}")
            }
        }
    }
}
