package com.example.arrowsolver

data class Cell(val x: Int, val y: Int)

enum class Direction(val dx: Int, val dy: Int) {
    UP(0, -1), RIGHT(1, 0), DOWN(0, 1), LEFT(-1, 0)
}

data class Arrow(
    val id: String,
    // All grid cells occupied by this arrow.
    val cells: List<Cell>,
    // The arrowhead/tip cell, i.e. the leading end in its direction of travel.
    val tip: Cell,
    val direction: Direction
)

data class Board(val width: Int, val height: Int, val arrows: List<Arrow>)

sealed class SolveResult {
    data class Solved(val order: List<String>) : SolveResult()
    data class Stuck(
        val remainingIds: List<String>,
        val blockers: Map<String, List<String>>
    ) : SolveResult()
    data class Invalid(val reason: String) : SolveResult()
}

object ArrowSolver {
    fun solve(board: Board): SolveResult {
        validate(board)?.let { return SolveResult.Invalid(it) }

        val remaining = board.arrows.associateBy { it.id }.toMutableMap()
        val order = mutableListOf<String>()

        while (remaining.isNotEmpty()) {
            val occupancy = mutableMapOf<Cell, String>()
            remaining.values.forEach { arrow ->
                arrow.cells.forEach { cell -> occupancy[cell] = arrow.id }
            }

            val available = remaining.values
                .filter { blockersFor(it, board, occupancy).isEmpty() }
                .sortedBy { it.id }

            if (available.isEmpty()) {
                val blockers = remaining.values.associate { arrow ->
                    arrow.id to blockersFor(arrow, board, occupancy).distinct()
                }
                return SolveResult.Stuck(remaining.keys.sorted(), blockers)
            }

            // Remove one currently free arrow, then recompute visibility.
            val selected = available.first()
            order += selected.id
            remaining.remove(selected.id)
        }

        return SolveResult.Solved(order)
    }

    private fun blockersFor(
        arrow: Arrow,
        board: Board,
        occupancy: Map<Cell, String>
    ): List<String> {
        val blockers = mutableListOf<String>()
        var x = arrow.tip.x + arrow.direction.dx
        var y = arrow.tip.y + arrow.direction.dy

        while (x in 0 until board.width && y in 0 until board.height) {
            val occupyingArrow = occupancy[Cell(x, y)]
            if (occupyingArrow != null && occupyingArrow != arrow.id) {
                blockers += occupyingArrow
            }
            x += arrow.direction.dx
            y += arrow.direction.dy
        }
        return blockers
    }

    private fun validate(board: Board): String? {
        if (board.width <= 0 || board.height <= 0) return "Board dimensions must be positive."
        if (board.arrows.isEmpty()) return null
        if (board.arrows.map { it.id }.toSet().size != board.arrows.size) {
            return "Arrow IDs must be unique."
        }

        val occupied = mutableSetOf<Cell>()
        for (arrow in board.arrows) {
            if (arrow.cells.isEmpty()) return "Arrow ${arrow.id} has no occupied cells."
            if (arrow.tip !in arrow.cells) return "Arrow ${arrow.id}: tip must belong to its cells."
            for (cell in arrow.cells) {
                if (cell.x !in 0 until board.width || cell.y !in 0 until board.height) {
                    return "Arrow ${arrow.id} contains an out-of-board cell."
                }
                if (!occupied.add(cell)) return "Two arrows overlap at (${cell.x}, ${cell.y})."
            }
        }
        return null
    }
}
