package com.example.arrowsolver

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ArrowSolverTest {
    @Test
    fun removesClearArrowBeforeArrowItBlocks() {
        val board = Board(5, 3, listOf(
            Arrow("A", listOf(Cell(1, 1), Cell(2, 1)), Cell(1, 1), Direction.LEFT),
            Arrow("B", listOf(Cell(3, 1), Cell(4, 1)), Cell(3, 1), Direction.LEFT)
        ))
        val result = ArrowSolver.solve(board)
        assertTrue(result is SolveResult.Solved)
        assertEquals(listOf("A", "B"), (result as SolveResult.Solved).order)
    }

    @Test
    fun detectsMutuallyBlockedArrows() {
        val board = Board(3, 3, listOf(
            Arrow("A", listOf(Cell(0, 1)), Cell(0, 1), Direction.RIGHT),
            Arrow("B", listOf(Cell(2, 1)), Cell(2, 1), Direction.LEFT)
        ))
        val result = ArrowSolver.solve(board)
        assertTrue(result is SolveResult.Stuck)
    }

    @Test
    fun rejectsOverlappingArrows() {
        val board = Board(3, 3, listOf(
            Arrow("A", listOf(Cell(1, 1)), Cell(1, 1), Direction.LEFT),
            Arrow("B", listOf(Cell(1, 1)), Cell(1, 1), Direction.RIGHT)
        ))
        assertTrue(ArrowSolver.solve(board) is SolveResult.Invalid)
    }
}
