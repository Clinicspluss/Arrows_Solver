# Arrow Solver Prototype 0.1

An Android Studio starter project containing the first pure-Kotlin arrow dependency solver.

## What works in this prototype
- Represents a board as a grid.
- Represents each arrow by its occupied cells, arrowhead/tip cell and direction.
- Checks the ray in front of each arrowhead for other arrows.
- Removes an available arrow and recalculates the board.
- Returns a complete elimination order, or reports the remaining blockers.
- Includes unit tests for a valid sequence, a blocked board and overlapping input.

## Run it
1. Install Android Studio.
2. Open this folder as an existing project.
3. Allow Gradle sync to complete (Android Gradle Plugin 8.7.3 / Kotlin 2.0.21).
4. Run the `app` configuration on an Android device or emulator.
5. Tap **Solve sample puzzle**.

Run unit tests with `./gradlew test` after creating/using a Gradle wrapper in Android Studio.

## Important limitations
This is the first algorithm prototype, not the finished automatic game player.
It does not yet capture another app's screen, recognise arrows from pixels, or tap the game.

The solver assumes:
- A rectangular grid.
- Straight arrows.
- Each arrow occupies known grid cells.
- The tip cell is the leading end of the arrow.
- An arrow is blocked by any other arrow occupying a cell on the ray from its tip to the board edge.

The actual game may use different movement/collision rules. Validate this assumption against a real unsolved level before connecting the solver to automated taps.

## Next integration stages
1. Obtain a screenshot from the target game and calibrate board/grid detection.
2. Implement arrow segmentation, direction and tip detection (OpenCV).
3. Convert detected arrows to `Board` objects and run the solver.
4. Add MediaProjection foreground-service screen capture with explicit user consent.
5. Add an AccessibilityService with an explicit user-enabled accessibility setting to dispatch taps.
6. Verify each tap by comparing the next captured frame; pause on uncertainty.

Do not use automated taps until the board has been recognised with high confidence and the proposed move has been revalidated against the latest frame.
